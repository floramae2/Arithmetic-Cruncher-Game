package com.example.arithmeticcrunchergame

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class FinishActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_finish)

        val score: Int = intent.getIntExtra("score", 0)
        val data: ArrayList<Question> = intent.getSerializableExtra("dataSet") as ArrayList<Question>
        val questionType: String? = intent.getStringExtra("questionType")

        val btnHome = findViewById<Button>(R.id.btnHome)
        val btnRetry = findViewById<Button>(R.id.btnRetry)
        val tvScore = findViewById<TextView>(R.id.tvScore)

        tvScore.text = "Your Score\n$score/10"
        setAdapterRecyclerView(data)

        btnHome.setOnClickListener {
            goToHome()
        }

        btnRetry.setOnClickListener {
            retryQuiz(questionType)
        }
    }

    private fun setAdapterRecyclerView(data: ArrayList<Question>) {
        val recyclerView: RecyclerView = findViewById(R.id.rvQuestionList)
        recyclerView.layoutManager = LinearLayoutManager(this)
        val adapter = QuestionAdapter(data)
        recyclerView.adapter = adapter
    }

    private fun retryQuiz(questionType: String?) {
        val intent = Intent(this, PlayActivity::class.java)
        intent.putExtra("questionType", questionType)
        startActivity(intent)
        finish()
    }

    private fun goToHome() {
        val intent = Intent(this, MainActivity::class.java)
        // Clearing the activity stack to make MainActivity the top and only activity in the stack
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
        finish()
    }
}
