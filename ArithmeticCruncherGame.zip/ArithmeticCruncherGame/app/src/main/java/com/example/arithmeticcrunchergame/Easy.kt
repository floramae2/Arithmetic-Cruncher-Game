package com.example.arithmeticcrunchergame

import kotlin.random.Random

object Easy {
    private var answer: Number = 0

    fun getQuestions(): Pair<String, Number> {
        val num1 = Random.nextInt(1, 100)
        val num2 = Random.nextInt(1, 100)
        val operator = arrayOf("+", "-", "*", "/", "%").random()

        val problem = "$num1 $operator $num2"

        answer = when (operator) {
            "+" -> num1 + num2
            "-" -> num1 - num2
            "*" -> num1 * num2
            "/" -> num1.toDouble() / num2
            "%" -> num1 % num2
            else -> throw IllegalArgumentException("Invalid operator")
        }

        return Pair(problem, answer)
    }
}
